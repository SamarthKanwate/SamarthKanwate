Syntax
num1 -eq num2
num1 -ge num2
num1 -gt num2
num1 -le num2
num1 -lt num2
num1 -ne num2 
