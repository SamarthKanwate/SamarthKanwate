echo code for iterating through a sentence

for X in I am Samarth  
do
	echo $X
done
