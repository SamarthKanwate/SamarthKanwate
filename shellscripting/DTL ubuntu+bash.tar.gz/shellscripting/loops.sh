
for i in {1..5}
do
    echo $i iteration
done

echo total semesters in engineering are:
for j in {1..8}
do
	echo semester $j
done
