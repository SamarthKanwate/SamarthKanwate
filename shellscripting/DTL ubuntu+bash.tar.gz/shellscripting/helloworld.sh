echo Hello World!
echo Yet Another line
echo This is getting boring
