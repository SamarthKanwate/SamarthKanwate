Explanation
is num1 equal to num2
is num1 greater than equal to num2
is num1 greater than num2
is num1 less than equal to num2
is num1 less than num2
is num1 not equal to num2
