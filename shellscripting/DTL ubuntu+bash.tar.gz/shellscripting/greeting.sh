
greeting=Heyy!
name=Samarth
echo $greeting $name
