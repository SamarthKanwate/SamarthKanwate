echo "Enter a Number"
read a

echo "Enter another number"
read b

var=$((a+b))
echo $var

